# Pratyush & Sanjukta — Digital Wedding Invitation

A responsive, single-page wedding invitation website in a Bengali royal style.

## Details currently included
- Wedding: 26 January 2027, 6:00 PM — Sankhrail, Howrah
- Reception: 28 January 2027, 6:00 PM — Jagaddal
- RSVP contact: 9000000000
- Countdown to the wedding
- Photo gallery placeholders
- Mobile-friendly scrolling layout

Exact venue addresses were not supplied, so the page explicitly asks for them to be added rather than inventing them.

## Preview on your computer
1. Extract the ZIP file.
2. Open `index.html` in a browser.

## Publish and get a shareable public link (Netlify Drop)
1. Open https://app.netlify.com/drop in your browser.
2. Sign in or create a Netlify account if prompted.
3. Extract this ZIP file first.
4. Drag the project folder containing `index.html` onto the Netlify Drop page (or select the folder if prompted).
5. Wait for the deployment to finish. Netlify will show a public URL.
6. Open that URL on your phone to test it, then share it with guests through WhatsApp.

Hosting interfaces can change. If the page asks for a folder, select the extracted folder that contains `index.html`. You can use the generated URL as your invitation link.

## Add your photographs
The gallery currently uses decorative placeholders. To add your own photos:
1. Create a folder called `images` beside `index.html`.
2. Copy your photos into it, for example `photo1.jpg`, `photo2.jpg`, and `photo3.jpg`.
3. In `index.html`, replace each `<div class="gallery-item">...</div>` placeholder with an image, for example:
   `<div class="gallery-item"><img src="images/photo1.jpg" alt="Pratyush and Sanjukta" style="width:100%;height:100%;object-fit:cover"></div>`
4. Repeat for each photo and redeploy the folder.

## Before sharing publicly
- Confirm the exact wedding and reception venue names/addresses.
- Confirm the RSVP phone number and whether it should include India's country code for messaging.
- Add the couple's own photographs if desired.
- Test the page and all details on a mobile phone.

This project is a static website; it does not collect or store RSVP submissions. The RSVP button starts a phone call on supported devices.
